// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.Incidents;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.pkerr204.mobileassignment.R;
import com.pkerr204.mobileassignment.ParserElements.Download;

import android.widget.EditText;
import android.widget.ListView;

public class IncidentsFragment extends Fragment
{

    private Handler mHandler = new Handler(Looper.getMainLooper());
    private ListView dataDisplay;
    private String result;
    private Button allmap;
    private EditText dummy;
    private EditText dummy1;
    private String urlSource = "https://trafficscotland.org/rss/feeds/currentincidents.aspx";


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.fragment_incidents, container, false);
        dataDisplay = root.findViewById(R.id.ListView);
        dataDisplay.setTextFilterEnabled(true);
        allmap = root.findViewById(R.id.AllMap);
        EditText editText = (EditText) root.findViewById(R.id.editTxt);
        FloatingActionButton fab = root.findViewById(R.id.FAB);
        fab.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                dataDisplay.setSelectionAfterHeaderView();
            }
        });
        new Download(IncidentsFragment.this.getActivity(), urlSource, dataDisplay, "incidents", editText, allmap, dummy, dummy1).execute();
        return root;
    }
}
