// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.FutureRoadworks;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;

import com.pkerr204.mobileassignment.R;
import java.util.ArrayList;

import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import java.util.Date;

public class FutureRoadworksAdapter extends ArrayAdapter<FutureRoadworksElement> implements Filterable {
    //Onclicklistener gets implemented
    private ArrayList<FutureRoadworksElement> plannedRoadworksElements;
    private ArrayList<FutureRoadworksElement> origPlannedRoadworksElements;
    private final Context context;
    private Filter plannedroadworksNameFilter;
    private Filter plannedroadworksSDateFilter;
    private Filter plannedroadworksEDateFilter;

    private static class ViewHolder {
        TextView txtName;
        TextView txtStart;
        TextView txtEnd;
        TextView txtDelay;
        TextView txtLink;
    }

    public FutureRoadworksAdapter(Context context, ArrayList<FutureRoadworksElement> plannedRoadworksItems) {
        super(context, R.layout.prw_list, plannedRoadworksItems);
        this.context = context;
        this.plannedRoadworksElements = plannedRoadworksItems;
        this.origPlannedRoadworksElements = plannedRoadworksItems;

    }

    public int getCount()
    {
        return plannedRoadworksElements.size();
    }

    public FutureRoadworksElement getItem(int position)
    {
        return plannedRoadworksElements.get(position);
    }

    public long getItemId(int position)
    {
        return plannedRoadworksElements.get(position).hashCode();
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        // Gets the data for the specified location
        FutureRoadworksElement plannedRoadworksItem = getItem(position);
        ViewHolder viewHolder;
        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.prw_list, parent, false);
            viewHolder.txtName = convertView.findViewById(R.id.name);
            viewHolder.txtStart = convertView.findViewById(R.id.SDate);
            viewHolder.txtEnd = convertView.findViewById(R.id.EDate);
            viewHolder.txtDelay = convertView.findViewById(R.id.Delay);

            result = convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }

        Animation animation = AnimationUtils.loadAnimation(context, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        result.startAnimation(animation);
        lastPosition = position;
        Date StartDate = null;
        if (plannedRoadworksItem != null) {
            StartDate = plannedRoadworksItem.getSDate();
        }
        Date EndDate = null;
        if (plannedRoadworksItem != null) {
            EndDate = plannedRoadworksItem.getEDate();
        }

        if (plannedRoadworksItem != null) {
            if (plannedRoadworksItem.getName().matches(".*Closure.*")) { //|| roadworksItem.getTitle().contains("Closure")){

            }
            viewHolder.txtName.setText(plannedRoadworksItem.getName());
        }
        if (StartDate != null) {
            viewHolder.txtStart.setText("Start Date: " + StartDate.toString());
        }
        if (EndDate != null) {
            viewHolder.txtEnd.setText("End Date: " + EndDate.toString());
        }
        if (plannedRoadworksItem != null)
        {
            if (plannedRoadworksItem.getDelay().matches(".*Closure.*")){}

            viewHolder.txtDelay.setText(plannedRoadworksItem.getDelay());

        }
//
        viewHolder.txtName.setTag(position);
        // Renders the view to the screen on return
        return convertView;
    }

    public void resetData() {
        plannedRoadworksElements = origPlannedRoadworksElements;
    }
    public Filter getNameFilter() {
        if (plannedroadworksNameFilter == null)
            plannedroadworksNameFilter = new RoadworkTitleFilter();

        return plannedroadworksNameFilter;
    }

    private class RoadworkTitleFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter gets implemented
            if (constraint == null || constraint.length() == 0) {
                // filter isn't used so the full list is shown
                results.values = origPlannedRoadworksElements;
                results.count = origPlannedRoadworksElements.size();
            } else {
                // Filter gets used
                ArrayList<FutureRoadworksElement> nRoadworkList = new ArrayList<>();

                for (FutureRoadworksElement p : plannedRoadworksElements) {
                    if (p.getName().toUpperCase().contains(constraint.toString().toUpperCase())) {
                        nRoadworkList.add(p);
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            // New list is filtered and the adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                plannedRoadworksElements = (ArrayList<FutureRoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }

    public Filter getSDateFilter() {
        if (plannedroadworksSDateFilter == null)
            plannedroadworksSDateFilter = new RoadworkStartDateFilter();

        return plannedroadworksSDateFilter;
    }


    private class RoadworkStartDateFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter implemented
            if (constraint == null || constraint.length() == 0) {
                // Filter isn't used so the full list is shown
                results.values = origPlannedRoadworksElements;
                results.count = origPlannedRoadworksElements.size();
            } else {
                // Filter gets used
                ArrayList<FutureRoadworksElement> nRoadworkList = new ArrayList<>();

                for (FutureRoadworksElement p : plannedRoadworksElements) {
                    Date SDate;
                    if (p != null) {
                        SDate = p.getSDate();
                        if (SDate != null) {
                            String Start = SDate.toString().toUpperCase();
                            String DateConstraint = constraint.toString().toUpperCase();
                            if (Start.startsWith(DateConstraint)) {
                                nRoadworkList.add(p);
                            }
                        }
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            // List is filtered and adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                plannedRoadworksElements = (ArrayList<FutureRoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }


    public Filter getEDateFilter() {
        if (plannedroadworksEDateFilter == null)
            plannedroadworksEDateFilter = new RoadworkEDateFilter();

        return plannedroadworksEDateFilter;
    }


    private class RoadworkEDateFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter gets implemented
            if (constraint == null || constraint.length() == 0) {
                // Filter isn't used so the full list is returned
                results.values = origPlannedRoadworksElements;
                results.count = origPlannedRoadworksElements.size();
            } else {
                // Filter gets used
                ArrayList<FutureRoadworksElement> nRoadworkList = new ArrayList<>();

                for (FutureRoadworksElement p : plannedRoadworksElements) {
                    Date EDate;
                    if (p != null) {
                        EDate = p.getEDate();
                        if (EDate != null) {
                            String End = EDate.toString().toUpperCase();
                            String DateConstraint = constraint.toString().toUpperCase();
                            if (End.startsWith(DateConstraint)) {
                                nRoadworkList.add(p);
                            }
                        }
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            // List has been filtered and the adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                plannedRoadworksElements = (ArrayList<FutureRoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }





}

