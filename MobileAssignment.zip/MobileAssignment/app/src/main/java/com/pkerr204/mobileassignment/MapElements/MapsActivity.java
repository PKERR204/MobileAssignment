// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.MapElements;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.ui.AppBarConfiguration;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.pkerr204.mobileassignment.MainActivity;
import com.pkerr204.mobileassignment.R;
import com.pkerr204.mobileassignment.FragmentElements.Incidents.IncidentsElement;
import com.pkerr204.mobileassignment.FragmentElements.FutureRoadworks.FutureRoadworksElement;
import com.pkerr204.mobileassignment.FragmentElements.Roadworks.RoadworksElement;

import java.util.ArrayList;
import java.util.Date;

import static com.pkerr204.mobileassignment.ParserElements.Parser.DateConversion;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private AppBarConfiguration mAppBarConfiguration;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        else if(id == android.R.id.home){
            Intent i= new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    /**

     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Bundle bundle = getIntent().getExtras();
        mMap = googleMap;
        if (bundle.get("Marker Amount").equals("Single")) {
            LatLng cords = new LatLng(bundle.getDouble("latitude"), bundle.getDouble("longitude"));
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(cords).title((bundle.getString("Marker Title"))).snippet(bundle.getString("Marker Snippet"));

            final InfoWindow info = new InfoWindow();
            info.setLink(bundle.getString("Link"));
            info.setDate(bundle.getString("PubDate"));


            GoogleMapCustom customInfoWindow = new GoogleMapCustom(this);
            mMap.setInfoWindowAdapter(customInfoWindow);

            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                @Override
                public void onInfoWindowClick(Marker arg0) {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.setData(Uri.parse(info.getLink()));
                    startActivity(intent);

                }
            });

            Marker m = mMap.addMarker(markerOptions);
            m.setTag(info);
            m.showInfoWindow();


            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(cords, 12.0f));
        }else if (bundle.get("Marker Amount").equals("Many")){
            Bundle b = getIntent().getExtras();
            if (b != null) {
                if (b.get("Type").equals("PlannedRoadworks")) {
                    ArrayList<FutureRoadworksElement> q = null;
                    q = b.getParcelableArrayList("Markers");
                    if (q != null) {
                        for (FutureRoadworksElement p : q) {
                            String desc = p.getDesc();
                            Date startDate = null;
                            Date endDate = null;
                            String DelayInfo = null;
                            try {


                                String[] seperate = desc.split("<br />");
                                startDate = DateConversion(seperate[0]);
                                endDate = DateConversion(seperate[1]);
                                DelayInfo = seperate[2];
                                DelayInfo = DelayInfo.trim();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            String Desc = "Start Date: " + startDate + "\nFinish Date: " + endDate + "\n" + DelayInfo;
                            LatLng cords = new LatLng(p.getCord().latitude, p.getCord().longitude);
                            MarkerOptions markerOptions = new MarkerOptions();
                            markerOptions.position(cords).title(p.getName()).snippet(Desc);

                            final InfoWindow info = new InfoWindow();
                            info.setLink(p.getLink());
                            info.setDate(p.getDate());


                            GoogleMapCustom customInfoWindow = new GoogleMapCustom(this);
                            mMap.setInfoWindowAdapter(customInfoWindow);

                            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                                @Override
                                public void onInfoWindowClick(Marker arg0) {
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_VIEW);
                                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                    intent.setData(Uri.parse(info.getLink()));
                                    startActivity(intent);

                                }
                            });

                            Marker m = mMap.addMarker(markerOptions);
                            m.setTag(info);

                        }
                    }
                }
                if (b.get("Type").equals("Roadworks")) {
                    ArrayList<RoadworksElement> q = null;
                    q = b.getParcelableArrayList("Markers");
                    if (q != null) {
                        for (RoadworksElement p : q) {
                            String desc = p.getDesc();
                            Date startDate = null;
                            Date endDate = null;
                            String DelayInfo = null;
                            try {


                                String[] seperate = desc.split("<br />");

                                startDate = DateConversion(seperate[0]);
                                endDate = DateConversion(seperate[1]);
                                DelayInfo = seperate[2];
                                DelayInfo = DelayInfo.trim();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            String Desc = "Start Date: " + startDate + "\nFinish Date: " + endDate + "\n" + DelayInfo;
                            LatLng cords = new LatLng(p.getCord().latitude, p.getCord().longitude);
                            MarkerOptions markerOptions = new MarkerOptions();
                            markerOptions.position(cords).title(p.getName()).snippet(Desc);

                            final InfoWindow info = new InfoWindow();
                            info.setLink(p.getLink());
                            info.setDate(p.getDate());


                            GoogleMapCustom customInfoWindow = new GoogleMapCustom(this);
                            mMap.setInfoWindowAdapter(customInfoWindow);

                            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                                @Override
                                public void onInfoWindowClick(Marker arg0) {

                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_VIEW);
                                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                    intent.setData(Uri.parse(info.getLink()));
                                    startActivity(intent);

                                }
                            });

                            Marker m = mMap.addMarker(markerOptions);
                            m.setTag(info);

                        }
                }
                }
                if (b.get("Type").equals("Incidents")) {
                    ArrayList<IncidentsElement> q = null;
                    q = b.getParcelableArrayList("Markers");
                    for (IncidentsElement p : q) {

                        LatLng cords = new LatLng(p.getCord().latitude,p.getCord().longitude);
                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.position(cords).title(p.getName()).snippet(p.getDesc());

                        final InfoWindow info = new InfoWindow();
                        info.setLink(p.getLink());
                        info.setDate(p.getDate());


                        GoogleMapCustom customInfoWindow = new GoogleMapCustom(this);
                        mMap.setInfoWindowAdapter(customInfoWindow);

                        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                            @Override
                            public void onInfoWindowClick(Marker arg0) {
                                Intent intent = new Intent();
                                intent.setAction(Intent.ACTION_VIEW);
                                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                intent.setData(Uri.parse(info.getLink()));
                                startActivity(intent);

                            }
                        });

                        Marker m = mMap.addMarker(markerOptions);
                        m.setTag(info);

                    }
                }
            }

        }
    }
}
