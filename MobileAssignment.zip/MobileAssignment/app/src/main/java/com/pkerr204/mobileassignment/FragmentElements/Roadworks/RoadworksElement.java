// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.Roadworks;


import android.os.Parcel;
import android.os.Parcelable;

import com.google.android.gms.maps.model.LatLng;

import java.util.Date;

public class RoadworksElement implements Parcelable {
    private String name;
    private String desc;
    private Date sDate;
    private Date eDate;
    private String delay;
    private String geo;
    private String link;
    private String date;
    private String writer;
    private String comments;
    private LatLng cord;

    public RoadworksElement(){
        this.writer = getWriter();
        this.comments= getComments();
        this.cord = getCord();
        this.date = getDate();
        this.link = getLink();
        this.geo = getGeo();
        this.delay = getDelay();
        this.eDate = getEDate();
        this.sDate=getSDate();
        this.desc=getDesc();
        this.name=getName();

    }

    protected RoadworksElement(Parcel in) {
        name = in.readString();
        desc = in.readString();
        delay = in.readString();
        geo= in.readString();
        link = in.readString();
        date = in.readString();
        writer = in.readString();
        comments = in.readString();
        cord= in.readParcelable(LatLng.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(desc);
        dest.writeString(delay);
        dest.writeString(geo);
        dest.writeString(link);
        dest.writeString(date);
        dest.writeString(writer);
        dest.writeString(comments);
        dest.writeParcelable(cord, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RoadworksElement> CREATOR = new Creator<RoadworksElement>() {
        @Override
        public RoadworksElement createFromParcel(Parcel in) {
            return new RoadworksElement(in);
        }

        @Override
        public RoadworksElement[] newArray(int size) {
            return new RoadworksElement[size];
        }
    };

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Date getSDate() {
        return sDate;
    }
    public void setSDate(Date sDate) {
        this.sDate = sDate;
    }

    public Date getEDate() {
        return eDate;
    }
    public void setEDate(Date eDate) {
        this.eDate = eDate;
    }

    public String getDelay() {
        return delay;
    }
    public void setDelay(String delay) {
        this.delay = delay;
    }

    public String getGeo() {
        return geo;
    }
    public void setGeo(String geo) {
        this.geo = geo;
    }

    public LatLng getCord() {
        return cord;
    }
    public void setCord(LatLng cord) {
        this.cord = cord;
    }

    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    public String getWriter() {
        return writer;
    }
    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "Title: " + getName()  + "\nStart Date: " + getSDate() + "\nEnd Date: " + getEDate() + "\n" + getDelay()
                + "\nLink: " + getLink()  + "\nGeoRSS Points: " + getGeo()  + "\nPublished Date: " + getDate();
    }
}
