// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.Roadworks;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.pkerr204.mobileassignment.R;

import java.util.ArrayList;
import java.util.Date;

public class RoadworksAdapter extends ArrayAdapter<RoadworksElement> implements Filterable {

    private ArrayList<RoadworksElement> roadworksElements;
    private final Context context;
    private Filter roadworkNameFilter;
    private Filter roadworkSDateFilter;
    private Filter roadworkEDateFilter;

    private ArrayList<RoadworksElement> origRoadworksElements;

    private static class ViewHolder {
        TextView txtName;
        TextView txtStart;
        TextView txtEnd;
        TextView txtDelay;
        TextView txtLink;
        ImageView imageView;

    }

    public RoadworksAdapter(Context context, ArrayList<RoadworksElement> roadworksElements) {
        super(context, R.layout.rw_list, roadworksElements);
        this.context = context;
        this.roadworksElements = roadworksElements;
        this.origRoadworksElements = roadworksElements;
    }

    public int getCount() {
        return roadworksElements.size();
    }

    public RoadworksElement getItem(int position) {
        return roadworksElements.get(position);
    }

    public long getItemId(int position) {
        return roadworksElements.get(position).hashCode();
    }


    private int lastPosition = -1;


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Gets the data for the position
        RoadworksElement roadworksItem = getItem(position);
        ViewHolder viewHolder;

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.rw_list, parent, false);
            viewHolder.txtName = convertView.findViewById(R.id.name);
            viewHolder.txtStart = convertView.findViewById(R.id.SDate);
            viewHolder.txtEnd = convertView.findViewById(R.id.EDate);
            viewHolder.txtDelay = convertView.findViewById(R.id.Delay);
            viewHolder.imageView = convertView.findViewById(R.id.icon);
            result = convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }

        Animation animation = AnimationUtils.loadAnimation(context, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        result.startAnimation(animation);
        lastPosition = position;
        Date StartDate = null;
        if (roadworksItem != null) {
            StartDate = roadworksItem.getSDate();
        }
        Date EndDate = null;
        if (roadworksItem != null) {
            EndDate = roadworksItem.getEDate();
        }


        if (roadworksItem != null) {
            CharSequence constraint = ("closure").toUpperCase();
            if (((roadworksItem.getName()).toUpperCase()).contains(constraint.toString().toUpperCase())){
                viewHolder.imageView.setImageResource(R.drawable.ic_closure);
            }
            viewHolder.txtName.setText(roadworksItem.getName());
        }
        if (StartDate != null) {
            viewHolder.txtStart.setText("Start Date: " + StartDate.toString());
        }
        if (EndDate != null) {
            viewHolder.txtEnd.setText("End Date: " + EndDate.toString());
        }
        if (roadworksItem != null) {
            viewHolder.txtDelay.setText(roadworksItem.getDelay());
        }
//
        if (StartDate != null && EndDate != null) {
            if (new Date().before(roadworksItem.getSDate()))
            {

            }else if (new Date().after(roadworksItem.getSDate()) && new Date().before(roadworksItem.getEDate()))
            {

            }else if (new Date().after(roadworksItem.getEDate())){

            }
        }
        viewHolder.txtName.setTag(position);
        // View is rendered to the screen
        return convertView;
    }

    public void resetData() {
        roadworksElements = origRoadworksElements;
    }

    public Filter getNameFilter() {
        if (roadworkNameFilter == null)
            roadworkNameFilter = new RoadworkTitleFilter();

        return roadworkNameFilter;
    }

    private class RoadworkTitleFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter is implemented
            if (constraint == null || constraint.length() == 0) {
                // Filter isn't used so full list is shown
                results.values = origRoadworksElements;
                results.count = origRoadworksElements.size();
            } else {
                // Filter is used
                ArrayList<RoadworksElement> nRoadworkList = new ArrayList<RoadworksElement>();

                for (RoadworksElement p : roadworksElements) {
                    if (p.getName().toUpperCase().contains(constraint.toString().toUpperCase())) {
                        nRoadworkList.add(p);
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            // List get filtered and adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                roadworksElements = (ArrayList<RoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }

    public Filter getSDateFilter() {
        if (roadworkSDateFilter == null)
            roadworkSDateFilter = new RoadworkSDateFilter();

        return roadworkSDateFilter;
    }


    private class RoadworkSDateFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter gets implemented
            if (constraint == null || constraint.length() == 0) {
                // Filter doesn't get used so full list is shown
                results.values = origRoadworksElements;
                results.count = origRoadworksElements.size();
            } else {
                // Filter gets used
                ArrayList<RoadworksElement> nRoadworkList = new ArrayList<RoadworksElement>();

                for (RoadworksElement p : roadworksElements) {
                    Date SDate;
                    if (p != null) {
                        SDate = p.getSDate();
                        if (SDate != null) {
                            String Start = SDate.toString().toUpperCase();
                            String DateConstraint = constraint.toString().toUpperCase();
                            if (Start.startsWith(DateConstraint)) {
                                nRoadworkList.add(p);
                            }
                        }
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            // List gets filtered and adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                roadworksElements = (ArrayList<RoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }


    public Filter getEDateFilter() {
        if (roadworkEDateFilter == null)
            roadworkEDateFilter = new RoadworkEDateFilter();

        return roadworkEDateFilter;
    }


    private class RoadworkEDateFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter is implemented
            if (constraint == null || constraint.length() == 0) {
                // No filter implemented we return all the list
                results.values = origRoadworksElements;
                results.count = origRoadworksElements.size();
            } else {
                // Filter gets used
                ArrayList<RoadworksElement> nRoadworkList = new ArrayList<RoadworksElement>();

                for (RoadworksElement p : roadworksElements) {
                    Date EDate;
                    if (p != null) {
                        EDate = p.getEDate();
                        if (EDate != null) {
                            String End = EDate.toString().toUpperCase();
                            String DateConstraint = constraint.toString().toUpperCase();
                            if (End.startsWith(DateConstraint)) {
                                nRoadworkList.add(p);
                            }
                        }
                    }
                }

                results.values = nRoadworkList;
                results.count = nRoadworkList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            //list has been filtered and adapter gets told
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                roadworksElements = (ArrayList<RoadworksElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }

}
