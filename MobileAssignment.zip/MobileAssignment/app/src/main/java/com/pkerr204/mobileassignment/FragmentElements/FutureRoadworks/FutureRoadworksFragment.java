// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.FutureRoadworks;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.pkerr204.mobileassignment.R;
import com.pkerr204.mobileassignment.ParserElements.Download;


public class FutureRoadworksFragment extends Fragment {

    private Handler mHandler = new Handler(Looper.getMainLooper());
    private ListView dataDisplay;
    private String result;
    private Button allmap;
    private String urlSource = "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_futureroadworks, container, false);
        dataDisplay = root.findViewById(R.id.ListView);
        dataDisplay.setTextFilterEnabled(true);
        allmap = root.findViewById(R.id.AllMap);
        EditText editText = (EditText) root.findViewById(R.id.editTxt);
        EditText datetxt = root.findViewById(R.id.Input_DateTxt);
        EditText date1text =root.findViewById(R.id.InputDate2Txt);
        FloatingActionButton fab =root.findViewById(R.id.FAB);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataDisplay.setSelectionAfterHeaderView();
            }
        });
        new Download (FutureRoadworksFragment.this.getActivity(),urlSource,dataDisplay,"plannedroadworks",editText,allmap,datetxt,date1text).execute();
        return root;
    }
}
