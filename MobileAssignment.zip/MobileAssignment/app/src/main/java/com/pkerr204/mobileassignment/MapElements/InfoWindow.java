// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.MapElements;

public class InfoWindow {
    private String Link;
    private String date;

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
