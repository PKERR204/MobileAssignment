// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.Incidents;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;


import com.pkerr204.mobileassignment.R;

import java.util.ArrayList;

public class IncidentsAdapter extends ArrayAdapter<IncidentsElement> implements Filterable {
    //Onclicklistener gets implemented
    private ArrayList<IncidentsElement> incidents;
    private Filter incidentFilter;
    private ArrayList<IncidentsElement> origIncidentsElement;

    private final Context context;

    private static class ViewHolder {
        TextView txtName;
        TextView txtDesc;

    }

    public IncidentsAdapter(Context context,ArrayList<IncidentsElement> incidentsElements) {
        super(context, R.layout.incidents_list, incidentsElements);
        this.context = context;
        this.incidents=incidentsElements;
        this.origIncidentsElement = incidentsElements;
    }

    public int getCount()
    {
        return incidents.size();
    }
    public IncidentsElement getItem(int position)
    {
        return incidents.get(position);
    }

    public long getItemId(int position)
    {
        return incidents.get(position).hashCode();
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        // Gets the data for the specified location
        IncidentsElement incidentsElement = getItem(position);
        ViewHolder viewHolder;
        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.incidents_list, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.name);
            viewHolder.txtDesc = (TextView) convertView.findViewById(R.id.desc);


            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        Animation animation = AnimationUtils.loadAnimation(context, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        result.startAnimation(animation);
        lastPosition = position;

        if (incidentsElement != null)
        {
            viewHolder.txtName.setText(incidentsElement.getName());
        }
        if (incidentsElement != null)
        {
            viewHolder.txtDesc.setText(incidentsElement.getDesc());
        }
        viewHolder.txtName.setTag(position);
        // Renders the view to the screen on return
        return convertView;
    }

    public void resetData()
    {
        incidents = origIncidentsElement;
    }

    public Filter getFilter() {
        if (incidentFilter == null)
            incidentFilter = new TitleFilter();

        return incidentFilter;
    }

    private class TitleFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // Filter gets implemented
            if (constraint == null || constraint.length() == 0) {
                // Returns the list
                results.values = origIncidentsElement;
                results.count = origIncidentsElement.size();
            } else {
                // Filter gets used
                ArrayList<IncidentsElement> nList = new ArrayList<IncidentsElement>();

                for (IncidentsElement p : incidents) {
                    if (p.getName().toUpperCase().contains(constraint.toString().toUpperCase())) {
                        nList.add(p);
                    }
                }

                results.values = nList;
                results.count = nList.size();

            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            // The adapter gets told about whats being filtered
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                incidents = (ArrayList<IncidentsElement>) results.values;
                notifyDataSetChanged();
            }

        }
    }


}
