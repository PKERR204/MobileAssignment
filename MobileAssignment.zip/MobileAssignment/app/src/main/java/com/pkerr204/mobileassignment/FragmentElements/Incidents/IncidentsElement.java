// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.FragmentElements.Incidents;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.maps.model.LatLng;

public class IncidentsElement implements  Parcelable
{
    private String name;

    private String desc;
    private String geo;
    private String link;
    private String date;
    private String writer;
    private String comments;
    private LatLng cord;

    public IncidentsElement(){
        this.writer = getWriter();
        this.comments= getComments();
        this.cord = getCord();
        this.date = getDate();
        this.link = getLink();
        this.geo = getGeo();
        this.desc=getDesc();
        this.name=getName();

    }

    protected IncidentsElement(Parcel in) {
        name = in.readString();
        desc = in.readString();
        geo = in.readString();
        link = in.readString();
        date = in.readString();
        writer = in.readString();
        comments = in.readString();
        cord = in.readParcelable(LatLng.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(desc);
        dest.writeString(geo);
        dest.writeString(link);
        dest.writeString(date);
        dest.writeString(writer);
        dest.writeString(comments);
        dest.writeParcelable(cord, flags);
    }

    @Override
    public int describeContents()
    {
        return 0;
    }

    public static final Creator<IncidentsElement> CREATOR = new Creator<IncidentsElement>()
    {
        @Override
        public IncidentsElement createFromParcel(Parcel in)
        {
            return new IncidentsElement(in);
        }

        @Override
        public IncidentsElement[] newArray(int size)
        {
            return new IncidentsElement[size];
        }
    };

    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getDesc()
    {
        return desc;
    }
    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    public String getGeo()
    {
        return geo;
    }
    public void setGeo(String geo)
    {
        this.geo = geo;
    }

    public LatLng getCord()
    {
        return cord;
    }
    public void setCord(LatLng cord)
    {
        this.cord = cord;
    }

    public String getLink()
    {
        return link;
    }
    public void setLink(String link)
    {
        this.link = link;
    }

    public String getDate()
    {
        return date;
    }
    public void setDate(String date)
    {
        this.date = date;
    }

    public String getWriter()
    {
        return writer;
    }
    public void setWriter(String writer)
    {
        this.writer = writer;
    }

    public String getComments()
    {
        return comments;
    }
    public void setComments(String comments)
    {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "Title: " + getName()  + "\nDescription: " + getDesc() + "\nLink: " + getLink()
                + "\nGeoRSS Points: " + getGeo()  + "\nPublished Date: " + getDate();
    }
}