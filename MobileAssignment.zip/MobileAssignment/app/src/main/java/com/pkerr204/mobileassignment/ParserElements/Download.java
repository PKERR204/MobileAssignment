// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.ParserElements;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;

public class Download extends AsyncTask<Void,Void,Object> {

    Context c;
    String urlAddress;
    ListView ListView;
    String item;
    EditText editText;
    ArrayList<LatLng> latlngs;



    ProgressDialog pd;
    private Button allmap;
    private EditText datetxt;
    private EditText date1txt;


    public Download(Context c, String urlAddress, ListView lv, String item, EditText editText,Button allmap,EditText date1txt,EditText date2txt) {
        this.c = c;
        this.urlAddress = urlAddress;
        this.ListView = lv;
        this.item = item;
        this.editText = editText;
        this.allmap = allmap;
        this.datetxt = date1txt;
        this.date1txt = date2txt;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Object doInBackground(Void... params) {
        return this.downloadData();
    }

    @Override
    protected void onPostExecute(Object data) {
        super.onPostExecute(data);
        //pd.dismiss();

        if (data.toString().startsWith("Error")) {
            Toast.makeText(c, data.toString(), Toast.LENGTH_SHORT).show();
        } else {
            //PARSE
            new Parser(c, (InputStream) data, ListView, item,editText,allmap,datetxt,date1txt).execute();
        }
    }

    private Object downloadData() {
        Object connection = Connect.connect(urlAddress);
        if (connection.toString().startsWith("Error")) {
            return connection.toString();
        }

        try {

            HttpURLConnection con = (HttpURLConnection) connection;
            InputStream is = new BufferedInputStream(con.getInputStream());
            return is;


        } catch (IOException e) {
            e.printStackTrace();
            return ErrorLog.IO_EROR;
        }
    }
}