// MobileAssignment
// Paul Kerr
// S1829525

package com.pkerr204.mobileassignment.MapElements;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.pkerr204.mobileassignment.R;

public class GoogleMapCustom implements GoogleMap.InfoWindowAdapter {

    private Context context;

    public GoogleMapCustom(Context ctx){
        context = ctx;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        View view = ((Activity)context).getLayoutInflater()
                .inflate(R.layout.custom_info_window, null);

        TextView title = view.findViewById(R.id.Name);
        TextView details = view.findViewById(R.id.info);
        TextView link = view.findViewById(R.id.link);
        TextView pubdate = view.findViewById(R.id.date);

        title.setText(marker.getTitle());
        details.setText(marker.getSnippet());

        InfoWindow infoWindowData = (InfoWindow) marker.getTag();

        link.setText(infoWindowData.getLink());
        pubdate.setText("Publication Date: "+infoWindowData.getDate());

        return view;
    }
}